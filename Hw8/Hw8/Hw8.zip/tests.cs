﻿using System;
using NUnit.Framework;

namespace CS422
{
	[TestFixture]
	public class tests
	{
		private static string current = AppDomain.CurrentDomain.BaseDirectory;
		private static string dirName = new System.IO.DirectoryInfo(System.IO.Path.GetDirectoryName(current)).Name;
		private StandardFileSystem sfs = StandardFileSystem.Create(current);

		[Test]
		public void NullRoot()
		{
			Assert.Null(sfs.GetRoot().Parent);
		}

		[Test]
		public void RootName()
		{
			StringAssert.AreEqualIgnoringCase("Debug", sfs.GetRoot().Name);
		}

		[Test]
		public void DirName()
		{
			StdFSDir d = new StdFSDir(dirName);
			StringAssert.AreEqualIgnoringCase("Debug", d.Name);
		}

		[Test]
		public void ParseDir()
		{
			StdFSDir sfd = new StdFSDir(dirName);
			StringAssert.AreEqualIgnoringCase("Debug", sfd.Name);
		}

		[Test]
		public void badRoot()
		{
			StandardFileSystem sfs2 = StandardFileSystem.Create("asdf");

			Assert.Null(sfs2);
		}

		[Test]
		public void differentRoot()
		{
			StandardFileSystem sfs2 = StandardFileSystem.Create("/Users");

			StringAssert.AreNotEqualIgnoringCase("/Users", sfs2.GetRoot().Name);
		}

		[Test]
		public void getDir_File()
		{
			StandardFileSystem sfs2 = StandardFileSystem.Create("/Users/drewm");
			Dir422 dir1 = sfs2.GetRoot().GetDir("Desktop");
			Assert.NotNull(dir1);


			Dir422 dir2 = dir1.GetDir("Ableton");
			Assert.NotNull(dir2);


			Dir422 dir3 = dir2.GetDir("wav files");
			Assert.NotNull(dir3);


			Assert.NotNull(dir3.GetFile("Cloud.wav"));
		}

		[Test]
		public void SysContains()
		{
			StandardFileSystem sfs2 = StandardFileSystem.Create("/Users/drewm");

			Dir422 dir1 = sfs2.GetRoot().GetDir("Desktop");
			Dir422 dir2 = dir1.GetDir("Ableton");
			Dir422 dir3 = dir2.GetDir("wav files");

			File422 f = dir3.GetFile("Cloud.wav");

			Assert.IsTrue(sfs2.Contains(f));
		}

		[Test]
		public void DirTests()
		{
			StandardFileSystem sfs2 = StandardFileSystem.Create("/Users/drewm");

			Dir422 dir1 = sfs2.GetRoot().GetDir("Desktop");

			//Assert.NotNull(dir1.CreateFile("hello.txt"));
			//Assert.NotNull(dir1.CreateFile("Test.txt"));

			Assert.NotNull(dir1.CreateDir("A"));
		}

		[Test]
		public void FileTests()
		{
			StandardFileSystem sfs2 = StandardFileSystem.Create("/Users/drewm");

			Dir422 dir1 = sfs2.GetRoot().GetDir("Desktop");
			Dir422 dir2 = dir1.GetDir("Ableton");
			Dir422 dir3 = dir2.GetDir("wav files");

			File422 f = dir3.GetFile("Cloud.wav");

			StringAssert.AreEqualIgnoringCase(f.Name, "Cloud.wav");
			StringAssert.AreEqualIgnoringCase(f.Parent.Name, "wav files");


		}
	}
}
